<?php
/**
 * Fired during plugin deactivation
 *
 * @link       https://kumapix.com
 * @since      1.0.0
 *
 * @package    Kocs
 * @subpackage Kocs/includes
 */
class KOCS_Deactivator {
	public static function deactivate() {
		// Actions for deactivation can be added here if needed in the future.
	}
}
