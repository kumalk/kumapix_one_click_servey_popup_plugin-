<!-- KumaPix One Click Survey Container -->
<div id="kocs-popup-overlay" class="kocs-hidden">
    <div id="kocs-popup-container">
        <button id="kocs-close-btn">&times;</button>
        <div id="kocs-survey-content">
            <h3 id="kocs-question"></h3>
            <div id="kocs-answers"></div>
        </div>
        <div id="kocs-thank-you" class="kocs-hidden">
            <h3>Thank You!</h3>
        </div>
    </div>
</div>
